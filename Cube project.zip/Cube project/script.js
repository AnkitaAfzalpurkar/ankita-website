const searchIcon = document.querySelector('.search-icon');
const searchBar = document.querySelector('.search-bar');
const searchInput = document.querySelector('.search-input');
const navLinks = document.querySelector('.nav-links');
const headerMain = document.querySelector('.header');

let searchVisible = false;

searchIcon.addEventListener('click', (event) => {
    event.stopPropagation(); // Prevent click from propagating to the header
    searchVisible = !searchVisible;
    searchBar.style.display = 'block';
    searchIcon.style.display = 'none';
    searchInput.classList.toggle('active', searchVisible);
    if (searchVisible) {
        searchInput.focus();
    }
    navLinks.style.display = searchVisible ? 'none' : 'flex';
    searchInput.style.display = searchVisible ? 'block' : 'none';
});

headerMain.addEventListener('click', () => {
    if (searchVisible) {
        searchVisible = false;
        searchBar.style.display = 'none'
        searchInput.classList.remove('active');
        navLinks.style.display = 'flex';
        searchIcon.style.display = 'block';
    }
});

// Prevent clicks inside the search input from closing the search
searchInput.addEventListener('click', (event) => {
    event.stopPropagation();
});

function hideSearch() {
  document.getElementById("mainHeader").style.display = "flex";
  document.getElementById("searchHeader").style.display = "none";
}
const hamburgerMenu = document.querySelector(".hamburger-menu");
const mobileNav = document.querySelector(".mobile-nav");

hamburgerMenu.addEventListener("click", () => {
  hamburgerMenu.classList.toggle("active");
  mobileNav.classList.toggle("active");
});

document.addEventListener("DOMContentLoaded", function () {
  let slideIndex = 0;
  const slides = document.querySelectorAll(".slides img");
  const dots = document.querySelectorAll(".dots-container .dot");
  const prevBtn = document.querySelector(".left-slider-container .prev");
  const nextBtn = document.querySelector(".left-slider-container .next");
  const gridImages = document.querySelectorAll(".image-grid .grid-image");

  // Debugging: Check if elements exist
  console.log("Prev Button:", prevBtn);
  console.log("Next Button:", nextBtn);
  console.log("Slides Count:", slides.length);
  console.log("Grid Images Count:", gridImages.length);

  if (!prevBtn || !nextBtn || slides.length === 0 || gridImages.length === 0) {
    console.error("One or more elements not found! Check HTML structure.");
    return;
  }

  function showSlide(index) {
    slides.forEach((slide, i) => {
      slide.style.display = i === index ? "block" : "none";
    });

    dots.forEach((dot, i) => {
      dot.classList.toggle("active", i === index);
    });
  }

  function changeSlide(direction) {
    slideIndex += direction;

    if (slideIndex >= slides.length) {
      slideIndex = 0;
    } else if (slideIndex < 0) {
      slideIndex = slides.length - 1;
    }

    showSlide(slideIndex);
  }

  function goToSlide(index) {
    slideIndex = index;
    showSlide(slideIndex);
  }

  // Handle clicking on grid images
  gridImages.forEach((img, index) => {
    img.addEventListener("click", () => {
      console.log("Grid Image Clicked:", img.src);

      // Find matching slide index
      slides.forEach((slide, slideIndexValue) => {
        if (slide.src === img.src) {
          slideIndex = slideIndexValue;
          showSlide(slideIndex);
        }
      });
    });
  });

  // Attach event listeners
  prevBtn.addEventListener("click", () => {
    console.log("Prev Clicked!");
    changeSlide(-1);
  });

  nextBtn.addEventListener("click", () => {
    console.log("Next Clicked!");
    changeSlide(1);
  });

  dots.forEach((dot, index) => {
    dot.addEventListener("click", () => goToSlide(index));
  });

  // Show first slide initially
  showSlide(slideIndex);
});

// Button Click Example
document.querySelector(".btn-primary").addEventListener("click", () => {
  alert("Redirecting to shop...");
});

function updateAddToCart() {
  const flavorRadios = document.querySelectorAll('input[name="flavor"]');
  const purchaseTypeRadios = document.querySelectorAll(
    'input[name="purchase-type"]'
  );
  const addToCartButton = document.querySelector("#addToCart");
  const hiddenDetails = document.querySelectorAll(".purchase-details");

  let selectedFlavor = "";
  let selectedPurchaseType = "";

  flavorRadios.forEach((radio) => {
    if (radio.checked) {
      selectedFlavor = radio.value;
    }
  });

  purchaseTypeRadios.forEach((radio) => {
    if (radio.checked) {
      selectedPurchaseType = radio.value;
    }
  });

  let newLink = "https://www.example.com/add-to-cart?";

  if (selectedFlavor) {
    newLink += `flavor=${selectedFlavor}`;
  }

  if (selectedPurchaseType) {
    if (selectedFlavor) {
      newLink += "&";
    }
    newLink += `type=${selectedPurchaseType}`;

    // Show/hide details based on the selected purchase type
    hiddenDetails.forEach((detail) => {
      if (detail.dataset.purchaseType === selectedPurchaseType) {
        detail.style.display = "block";
      } else {
        detail.style.display = "none";
      }
    });
  } else {
    // Hide all purchase type details if none are selected
    hiddenDetails.forEach((detail) => {
      detail.style.display = "none";
    });
  }

  addToCartButton.href = newLink;
}

// Add event listeners to the radio buttons
document.addEventListener("DOMContentLoaded", () => {
  const flavorRadios = document.querySelectorAll('input[name="flavor"]');
  const purchaseTypeRadios = document.querySelectorAll(
    'input[name="purchase-type"]'
  );

  flavorRadios.forEach((radio) => {
    radio.addEventListener("change", updateAddToCart);
  });

  purchaseTypeRadios.forEach((radio) => {
    radio.addEventListener("change", updateAddToCart);
  });

  // Initialize on page load
  updateAddToCart();
});

const subscribeButton = document.querySelector(".subscribe-button");
if (subscribeButton) {
  subscribeButton.addEventListener("click", () => {
    alert("Subscribe Now button clicked!");
    // In a real scenario, you would redirect the user to the subscription page.
  });
}

document.addEventListener("DOMContentLoaded", function () {
  const videoContainer = document.querySelector(".video-container");
  const videoPlayer = document.querySelector(".video-player");
  const videoThumbnail = document.querySelector(".video-thumbnail");
  const playButton = document.querySelector(".play-button");

  videoContainer.addEventListener("click", function () {
    videoThumbnail.style.display = "none";
    playButton.style.display = "none";
    videoPlayer.style.display = "block";
    videoPlayer.play();
  });

  // Optional: Handle pause/play when the video itself is clicked
  videoPlayer.addEventListener("click", function () {
    if (videoPlayer.paused) {
      videoPlayer.play();
    } else {
      videoPlayer.pause();
    }
  });

  // Optional: Show play button again when video ends
  videoPlayer.addEventListener("ended", function () {
    videoThumbnail.style.display = "block";
    playButton.style.display = "flex"; // Or 'block' depending on your button style
    videoPlayer.style.display = "none";
    videoPlayer.currentTime = 0; // Reset video to the beginning
  });
});

document.querySelectorAll(".faq-question").forEach((question) => {
  question.addEventListener("click", () => {
    const faqItem = question.parentElement;

    // Toggle active class
    faqItem.classList.toggle("active");
  });
});

function subscribe() {
  let email = document.getElementById("emailInput").value;
  let errorMessage = document.getElementById("error-message");

  if (email.trim() === "") {
    errorMessage.textContent = "Please enter your email!";
  } else {
    errorMessage.textContent = "";
    alert("Thank you for subscribing!");
    href="#"
  }
}
function startCounter(entries, observer) {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      const stat = entry.target;
      const target = parseInt(stat.getAttribute("data-target"));
      let count = 0;
      const speed = 75; // Speed of counting

      const updateCount = () => {
        if (count < target) {
          count += 1;
          stat.textContent = count + "%";
          setTimeout(updateCount, speed);
        } else {
          stat.textContent = target + "%";
        }
      };
      updateCount();
    }
  });
}

const observer = new IntersectionObserver(startCounter, {
  threshold: 0.5, // Triggers when 50% of the section is in view
});

document.querySelectorAll(".stat").forEach((stat) => {
  observer.observe(stat);
});
// document.addEventListener("DOMContentLoaded", () => {
//   const carousel = document.querySelector(".carousel");
//   const cards = document.querySelectorAll(".testimonial-card");
//   const prevBtn = document.querySelector(".prev-btn");
//   const nextBtn = document.querySelector(".next-btn");
//   const dotsContainer = document.querySelector(".carousel-dots");
//   const cardWidth = cards[0].offsetWidth;
//   let currentIndex = 0;
//   const totalCards = cards.length;
//   const visibleCardsCount = 3; // Only 3 card visible at a time

//   // Initially hide all cards except the first 3
//   cards.forEach((card, index) => {
//     if (index !== 3) {
//       card.style.display = "none";
//     }
//   });

//   function updateCarousel() {
//     // Hide all cards
//     cards.forEach((card) => {
//       card.style.display = "none";
//     });

//     // Show the card at the current index
//     if (cards[currentIndex]) {
//       cards[currentIndex].style.display = "block";
//     }

//     updateDots();
//     updateArrowStates();
//   }

//   function createDots() {
//     dotsContainer.innerHTML = "";
//     for (let i = 0; i < totalCards; i++) {
//       const dot = document.createElement("div");
//       dot.classList.add("dot");
//       dot.dataset.index = i;
//       dot.addEventListener("click", () => {
//         currentIndex = parseInt(dot.dataset.index);
//         updateCarousel();
//       });
//       dotsContainer.appendChild(dot);
//     }
//     updateDots();
//   }

//   function updateDots() {
//     const dots = dotsContainer.querySelectorAll(".dot");
//     dots.forEach((dot, index) => {
//       dot.classList.remove("active");
//       if (index === currentIndex) {
//         dot.classList.add("active");
//       }
//     });
//   }

//   function updateArrowStates() {
//     prevBtn.classList.remove("active");
//     nextBtn.classList.remove("active");
//   }

//   function nextSlide() {
//     nextBtn.classList.add("active");
    
//     setTimeout(() => {
//       nextBtn.classList.remove("active");
//       prevBtn.style.background = 'black';
//     }, 200);
//     if (currentIndex < totalCards - 1) {
//       currentIndex++;
//       updateCarousel();
//     }
//   }

//   function prevSlide() {
//     prevBtn.classList.add("active");
    
//     setTimeout(() => {
//       prevBtn.classList.remove("active");
//       prevBtn.style.background = 'black';
//     }, 200);
//     if (currentIndex > 0) {
//       currentIndex--;
//       updateCarousel();
//     }
//   }

//   prevBtn.addEventListener("click", prevSlide);
//   nextBtn.addEventListener("click", nextSlide);

//   createDots();
//   updateCarousel();
// });
document.addEventListener('DOMContentLoaded', () => {
    const carousel = document.querySelector('.carousel');
    const cards = document.querySelectorAll('.testimonial-card');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const dotsContainer = document.querySelector('.carousel-dots');
    const totalCards = cards.length;
    let currentIndex = 0;
    let cardsToShow = 1; // Default to 1 card

    function updateCardsToShow() {
        if (window.innerWidth >= 768) {
            cardsToShow = 3;
        } else {
            cardsToShow = 1;
        }
    }

    updateCardsToShow();
    window.addEventListener('resize', updateCardsToShow);

    function updateCarousel() {
        const translateX = -currentIndex * (cards[0].offsetWidth + 15);
        carousel.style.transform = `translateX(${translateX}px)`;
        updateDots();
        updateArrowStates();
    }

    function createDots() {
        dotsContainer.innerHTML = '';
        const numDots = Math.ceil(totalCards / cardsToShow);
        for (let i = 0; i < numDots; i++) {
            const dot = document.createElement('div');
            dot.classList.add('dot');
            dot.dataset.index = i;
            dot.addEventListener('click', () => {
                currentIndex = i * cardsToShow;
                updateCarousel();
            });
            dotsContainer.appendChild(dot);
        }
        updateDots();
    }

    function updateDots() {
        const dots = dotsContainer.querySelectorAll('.dot');
        dots.forEach((dot, index) => {
            dot.classList.remove('active');
            if (index === Math.floor(currentIndex / cardsToShow)) {
                dot.classList.add('active');
            }
        });
    }

    function updateArrowStates() {
        prevBtn.classList.remove('active');
        nextBtn.classList.remove('active');
    }

    function nextSlide() {
        nextBtn.classList.add('active');
        nextBtn.style.background = 'black';
        setTimeout(() => {
            nextBtn.classList.remove('active');
            nextBtn.style.background = '#faebd787';
        }, 200);
        const maxIndex = totalCards - cardsToShow;
        if (currentIndex < maxIndex) {
            currentIndex += cardsToShow;
        } else if (currentIndex < totalCards) {
            currentIndex = totalCards - cardsToShow;
        }
        updateCarousel();
    }

    function prevSlide() {
        prevBtn.classList.add('active');
        prevBtn.style.background = 'black';
        setTimeout(() => {
            prevBtn.classList.remove('active');
            prevBtn.style.background = '#faebd787';
        }, 200);
        if (currentIndex > 0) {
            currentIndex -= cardsToShow;
            if (currentIndex < 0) {
                currentIndex = 0;
            }
        }
        updateCarousel();
    }

    prevBtn.addEventListener('click', prevSlide);
    nextBtn.addEventListener('click', nextSlide);

    createDots();
    updateCarousel();
});